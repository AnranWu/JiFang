(function(){
try{
var d=window._CNZZDbridge_2982771.bobject;
var scheme =  (document.location.protocol=='https:')?'https:':'http:';
d.callRequest([]);
d.callScript([]);
        d.createIcon(["<a href='http://www.cnzz.com/stat/website.php?web_id=2982771' target=_blank title='&#31449;&#38271;&#32479;&#35745;'>&#31449;&#38271;&#32479;&#35745;</a>"])}catch(err){
}
})();
